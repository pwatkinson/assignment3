Steps to create the program
1. npx create-react-app app
2. cd app
3. npm start
4. npm install prop-types
5. npm install react-router-dom
6. npm install axios