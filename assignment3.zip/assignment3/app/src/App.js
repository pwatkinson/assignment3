import React, { useState, useEffect } from "react";
import axios from "axios";
import { Switch, Route } from "react-router-dom";
import styles from "./App.module.css";

// Import Components
import Header from "./components/Header/Header";
import Loading from "./components/Loading/Loading";

// Import Pages
import Home from "./pages/Home/Home";
import About from "./pages/About/About";
import Character from "./pages/Character/Character";
import Contact from "./pages/Contact/Contact";

function App() {
  const [loading, setLoading] = useState(true);
  const [characters, setCharacters] = useState([]);

  // useEffect runs after the component renders
  useEffect(() => {
    const loadingTimer = setTimeout(() => {
      clearTimeout(loadingTimer);
      // Every time we change the state, we cause the component
      // to re-render

      // Once 2000ms is up, we make the call, any additional time that it takes
      // for the data to return to us will add up
      axios
        .get("https://pokeapi.co/api/v2/pokemon?limit=151")
        .then(response => {
          //console.log(response.data.results);
          setCharacters(response.data.results);
          setLoading(false);
        });
    }, 2000);
  }, []);

  return (
    <div className={styles.app}>
      <div className={styles.header}>
        <Header />
      </div>
      <div className={styles.content}>
        {loading ? (
          <Loading />
        ) : (
          <Switch>
            <Route exact path="/" render={() => {
                return <Home characters={characters} />;
              }}
            />
            <Route exact path="/about" component={About} />
            {/* The :id is a URL variable / parameter */}
            {/* 
              Pass the blogId variable from the url into props {...props}
              Pass the posts from App state into BlogPost props posts={posts}
              BlogPost now has all the data needed available in it's props
            */}
            <Route path="/character/:Id" render={props => {
                return <Character characters={characters} {...props} />;
              }}
            />
            <Route exact path="/contact" component={Contact} />
          </Switch>
        )}
      </div>
    </div>
  );
}

export default App;
