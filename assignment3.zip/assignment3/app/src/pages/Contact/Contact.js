import React from 'react';
import styles from './Contact.module.css';

import Card from '../../components/Card/Card';

const Contact = (props) => {
    return (
        <div className={styles.contact}>
            <Card>
                <p><strong>Email: </strong>philip.gary.watkinson@gmail.com</p>
            </Card>
        </div>
    );
};

export default Contact;
