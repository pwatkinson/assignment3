import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import PropTypes from 'prop-types';
import styles from "./Character.module.css";

import Loading from "../../components/Loading/Loading";
import Card from "../../components/Card/Card";

const Character = props => {
  //console.log("Character component");
  //console.log(props);
  const { Id } = props.match.params;
  //console.log("Id=" + Id);
  const character = props.characters[Id];
  //console.log(character);
  //const characterName = character.name;
  const characterUrl = character.url;
  //console.log(characterName);
  //console.log(characterUrl);

  const [loadingCharacter, setLoadingCharacter] = useState(true);
  //const [characterData, setCharacterData] = useState([]);
  const [stats, setStats] = useState([]);
  const [name, setName] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  // useEffect runs after the component renders
  useEffect(() => {
    const loadingTimer = setTimeout(() => {
      clearTimeout(loadingTimer);
      // Every time we change the state, we cause the component
      // to re-render

      // Once 2000ms is up, we make the call, any additional time that it takes
      // for the data to return to us will add up
      axios.get(characterUrl).then(response => {
        //setCharacterData(response.data);
        setStats(response.data.stats);
        setName(response.data.species.name);
        setImageUrl(response.data.sprites.front_default);
        //
        setLoadingCharacter(false);
      });
    }, 2000);
  }, [characterUrl]);

  // debugging
  //console.log("characterData=" + characterData);
  //console.log("name=" + name);
  //console.log("imageUrl=" + imageUrl);
  //console.log(stats);

  //let size = stats.length;
  //console.log("number of stats=" + size);

  //for (let i = 0; i < size; i++) {
  //  let stat = stats[i].stat.name;
  //  let value = stats[i].base_stat;
  //  console.log("stat=" + stat + ", value=" + value);
  //}

  return (
    <div className={styles.blogPost}>
      {loadingCharacter ? (
        <Loading />
      ) : (
        <Card>
          <h2>Name: {name}</h2>
          <img src={imageUrl} width="250" alt="PokeMon character" />
          <table>
            <thead>
              <tr>
                <th>Statistic</th>
                <th>Value</th>
              </tr>
            </thead>
            <tbody>
              {stats.map((entry, index) => {
                return (
                  <tr key={index}>
                    <td>{entry.stat.name}</td>
                    <td>{entry.base_stat}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
          <Link to="/">Exit</Link>          
        </Card>
      )}
    </div>
  );

};

Character.propTypes = {
  characters: PropTypes.array,
  children: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.element,
    PropTypes.node,
])
};

export default Character;
