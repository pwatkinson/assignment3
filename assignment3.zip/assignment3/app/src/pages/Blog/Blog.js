import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Blog.module.css';

import Card from '../../components/Card/Card';

const Blog = (props) => {
    const { characters } = props;
    console.log(characters);
	
	{/*
	
    return (
        <div className={styles.blog}>
            {posts.map((post) => {
                return (
                    <section>
                        <Card>
                            <h2>{post.title}</h2>
                            <p>{post.body}</p>
                            <Link to={`/blog/${post.id}`}>Read More >></Link>
                        </Card>
                    </section>
                )
            })}
        </div>
    );
	
	*/}
	return (<div></div>);
}

export default Blog;