import React from 'react';
import styles from './About.module.css';

import Card from '../../components/Card/Card';

const About = () => {
    return (
        <div className={styles.about}>
            <Card>
				<p>This React application is the third assignment for WEB301. It uses the PokeAPI to load and display pokemon characters.</p>
            </Card>
        </div>
    );
};

export default About;
