import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import styles from './Home.module.css';
import Card from '../../components/Card/Card';

const Home = (props) => {
    //console.log("Home component");
    //console.log(props);
    const { characters } = props;
    //console.log(characters);
	
    return (
        <div className={styles.home}>
            {characters.map((character, index) => {
                return (
                    <div key={'myKey' + index}>
                        <Card className={styles.card}>
                            <h2>Pokemon Character: {character.name}</h2>
							<Link to={`/character/${index}`}>Stats >></Link>
                        </Card>
                    </div>
                )
            })}
        </div>
    );
	
}

Home.propTypes = {
    characters: PropTypes.array
};

export default Home;
