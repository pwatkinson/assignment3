import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import styles from './BlogPost.module.css';

import Loading from '../../components/Loading/Loading';
import Card from '../../components/Card/Card';

const BlogPost = (props) => {
    console.log(props);
    // Grab all the data you need from props
    const { Id } = props.match.params;
	console.log("Id=" + Id);
	const character = props.characters[Id];
	console.log(character);
	const characterName=character.name;
	const characterUrl = character.url;
	console.log(characterName);
	console.log(characterUrl);
	
  const [loadingCharacter, setLoadingCharacter] = useState(true);
  const [characterData, setCharacterData] = useState([]);
  const [stats, setStats] = useState([]);
  const [name, setName] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  
  const rows = [];

  // useEffect runs after the component renders
  useEffect(() => {
    const loadingTimer = setTimeout(() => {
      clearTimeout(loadingTimer);
      // Every time we change the state, we cause the component
      // to re-render

      // Once 2000ms is up, we make the call, any additional time that it takes
      // for the data to return to us will add up
      axios.get(characterUrl).then((response) => {		  
        setCharacterData(response.data);
		setStats(response.data.stats);
		setName(response.data.species.name);
		setImageUrl(response.data.sprites.front_default);
		//
        setLoadingCharacter(false);
		// debugging
		console.log(characterData);
		console.log(name);
		console.log(imageUrl);
		console.log(stats);
	
		let size=stats.length;
		console.log(size);
		
		for (let i = 0; i < size; i++) {
			let stat = stats[i].stat.name;
			let statUrl = stats[i].stat.url;
			rows.push({stat});
			console.log(stat, statUrl);
		}		
      });
    }, 2000);
  }, []);	
	
    return (
        <div className={styles.blogPost}>
			{loadingCharacter ? (
				<Loading />
			) : (
				<Card>
					<h2>Name: {name}</h2>
					<p>Image:</p>
					<img src={imageUrl} width="250" alt="PokeMon character" />
					<Link to="/">Go Back</Link>
					<div>
						{rows}
					</div>
				</Card>
			)}

        </div>
    );	  
	

	{/*
	
    // Use filter() to filter arrays, it will return an array
    // with items that pass the filter function test
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter
    const filteredPosts = posts.filter((post) => {
      // The rule we set is that the post id must match the blogId
      // from the url
      return post.id == blogId;
    });

    // We should get an array with only one object
    console.log(filteredPosts);

    // const { blogId } = props.match.params;
    return (
        <div className={styles.blogPost}>
            <Card>
                <h2>{filteredPosts[0].title}</h2>
                <p>{filteredPosts[0].body}</p>
                <Link to="/blog">Go Back</Link>
            </Card>
        </div>
    );
	
	return ( <div></div> );
	*/}

}

export default BlogPost;